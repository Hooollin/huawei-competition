
#pragma once
//操作类型
#define ADD 1
#define DEL 2

// 虚拟机所在节点：A、B、BOTH,虚拟机可部署节点：1.单节点下:A,B,BOTH,NONE2.双节点下:BOTH,NONE
#define A 3
#define B 4
#define BOTH 5
#define NONE 0
//#define DEBUG
