#pragma once
#include <string>
using namespace std;

class OP{
    public:
        int opType;
        int id;
        string machineType;
        OP(){}
};

